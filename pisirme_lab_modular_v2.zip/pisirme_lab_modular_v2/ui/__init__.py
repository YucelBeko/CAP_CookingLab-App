"""Shared Streamlit UI helpers."""
